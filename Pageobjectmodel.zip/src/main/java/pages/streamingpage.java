package pages;

import org.openqa.selenium.By;

import Base.projectspecificmethods;

public class streamingpage extends projectspecificmethods {

	public void live() {
		driver.findElement(By.xpath("//span[text()='LIVE']")).click();
		
	}
	
	
}
