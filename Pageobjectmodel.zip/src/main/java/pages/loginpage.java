package pages;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;

import Base.projectspecificmethods;

public class loginpage extends projectspecificmethods {

	public void linktvprovider() {
		driver.findElement(By.xpath("//span[text()='Link TV Provider']")).click();
	}

	
	public void verizon() {
		
		driver.findElement(By.xpath("//img[@alt='Verizon']")).click();
		Set<String> windowHandles = driver.getWindowHandles();
		List<String> allWindows = new ArrayList<String>(windowHandles);
		driver.switchTo().window(allWindows.get(1));
	}
			
			
	public void username() {
		driver.findElement(By.xpath("//input[@id = 'IDToken1']")).sendKeys("NBCTest");

	}

	public void password() {
		driver.findElement(By.xpath("//input[@id = 'IDToken2']")).sendKeys("mobile123");

	}

	public void loginbutton() {
		driver.findElement(By.xpath("//button[text()= 'Sign In']")).click();
		Set<String> windowHandles = driver.getWindowHandles();
		List<String> allWindows = new ArrayList<String>(windowHandles);
		driver.switchTo().window(allWindows.get(0));
	}
	

	public void skipbutton() {
		
		driver.findElement(By.xpath("//button[@class = 'button button--hollow provider-linked-page__cta-skip']")).click();
		
	}

}
