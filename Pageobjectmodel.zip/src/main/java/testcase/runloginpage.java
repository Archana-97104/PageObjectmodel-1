package testcase;

import org.testng.annotations.Test;

import Base.projectspecificmethods;
import pages.loginpage;
import pages.streamingpage;

public class runloginpage extends projectspecificmethods {

	@Test
	public void runlogin() {
		loginpage lp = new loginpage();
		lp.linktvprovider();
		
		lp.verizon();
		lp.username();
		lp.password();
		lp.loginbutton();
		lp.skipbutton();
		
		
		streamingpage sp = new streamingpage();
		sp.live();
	}
	
	
		
		
		
		
	}
	

		
		
	

